import React, { useEffect, useState } from 'react';
import AddTasks from './AddTasks';

function AllTasks() {
    const [taskObj, setTaskObj] = useState([]);
    const [taskName, setTaskName] = useState('');
    const [priority, setPriority] = useState(0);
    const [status, setStatus] = useState('0');
    const [id, setId] = useState('');

    const [isEdit, setEdit] = useState(0);

    //Delete task
    const deleteTask = (taskId) => {
        const response = fetch(
            `http://localhost:5030/Tasks?id=${taskId}`,
            {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                },
            }
        ).then((response) => {
            alert("Task deleted!")
            getAll();
        }).catch((error) => {
            console.log(error);
        });
    };

    //Update task
    const handleUpdate = async (e) => {
        e.preventDefault();
        if (taskName === "") {
            alert("Task name is required");
            return;
        }

        const response = fetch(
            `http://localhost:5030/Tasks?id=${id}&name=${taskName}&priority=${priority}&status=${status}`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
            }
        ).then((response) => {
            setEdit(0);
            getAll();

        }).catch((error) => {
            console.log(error);
        });
    };

    //On click of edit button
    const editTask = (data) => {
        setTaskName(data.taskName);
        setPriority(data.priority);
        setStatus(data.status);
        setId(data.taskId);
        setEdit(1);
    }

    //get all the data
    const getAll = async () => {
        fetch("http://localhost:5030/Tasks", {
            method: "GET",
            headers: {
                "access-control-allow-origin": "*",
                "Content-type": "application/json; charset=UTF-8",
                //   "Authorization": "Bearer "
            }
        })
            .then((response) => {
                response.json()
                    .then((response) => {
                        //console.log(response);
                        setTaskObj(response);
                    })
            }).catch((error) => {
                console.log(error);
            });
    };
    useEffect(() => {
        getAll();
    }, []);

    return (
        <div style={{margin: "auto", width: "60%"}}>
            <AddTasks getAllData={getAll} />
            <br/>
            <table style={{textAlign:"left"}}>
                <thead>
                    <tr>
                        <th>Task Name</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Delete</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {taskObj.map((data) =>
                        <tr key={data.taskId}>
                            <td>{data.taskName}</td>
                            <td>{data.priority}</td>
                            <td> {data.status == 0 ? "Not Started" : data.status == 1 ? "In Progress" : "Completed"}</td>
                            <td>{data.status == 2 ? <button onClick={() => deleteTask(data.taskId)} style={{ color: "red", cursor: "pointer" }}>Delete</button> : "---"}</td>
                            <td><button type='Submit' onClick={() => editTask(data)}>Edit</button></td>

                        </tr>
                    )}
                </tbody>
            </table>
            <br />
                    
            
            {isEdit == 1 ? (<form onSubmit={handleUpdate}>
                <h1> Update task</h1>
                <div>
                    <label>Task Name:</label>
                    <input
                        type="text"
                        value={taskName}
                        onChange={(e) => setTaskName(e.target.value)}
                    />
                </div>
                <div>
                    <label>Priority:</label>
                    <input
                        type="number"
                        value={priority}
                        onChange={(e) => setPriority(parseInt(e.target.value))}
                        min="0" max="5"
                        required
                    />
                </div>
                <div>
                    <label>Status:</label>
                    <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                    >
                        <option value="0">Not Started</option>
                        <option value="1">In Progress</option>
                        <option value="2">Completed</option>
                    </select>
                </div>

                <button type="submit">Update Task</button>

            </form>) : ("")}
            
        </div>
    )
}

export default AllTasks;